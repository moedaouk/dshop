const html = document.documentElement;
document.getElementById('themeToggle')?.addEventListener('click', () => {
  const dark = html.getAttribute('data-bs-theme') !== 'dark';
  html.setAttribute('data-bs-theme', dark ? 'dark' : 'light');
});
const cartDrawer = document.getElementById('cartDrawer');
if (cartDrawer) {
  cartDrawer.addEventListener('show.bs.offcanvas', () => {
    const n = document.getElementById('cust_name')?.value || '';
    const p = document.getElementById('cust_phone')?.value || '';
    const notes = document.getElementById('cust_notes')?.value || '';
    const ocn = document.getElementById('oc_name'); const ocp = document.getElementById('oc_phone'); const ocnotes = document.getElementById('oc_notes');
    if (ocn) ocn.value = n; if (ocp) ocp.value = p; if (ocnotes) ocnotes.value = notes;
  });
}
